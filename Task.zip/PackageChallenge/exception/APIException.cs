﻿using System;

namespace com.code.challenge.exception
{
	public class APIException : Exception
	{

		public APIException(string message) : base(message)
		{
		}

		public APIException(Exception cause) 
		{
		}
	}

}