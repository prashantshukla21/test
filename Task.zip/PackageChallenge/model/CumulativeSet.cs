﻿using System.Collections.Generic;

namespace com.code.challenge.model
{

	/// <summary>
	/// Set Created as a result of merge operation.
	/// </summary>
	public class CumulativeSet
	{
		private IList<Triplet> triplets;
		private readonly int maximumCapacity;

		public CumulativeSet(IList<Triplet> triplets, int maximumCapacity)
		{
			this.triplets = triplets;
			this.maximumCapacity = maximumCapacity;
		}

		public CumulativeSet(int maximumCapacity)
		{
			this.maximumCapacity = maximumCapacity;
			this.triplets = new List<Triplet>();
		}

		public virtual IList<Triplet> Triplets
		{
			get
			{
				return triplets;
			}
		}

		public virtual int MaximumCapacity
		{
			get
			{
				return maximumCapacity;
			}
		}

		/// <summary>
		/// Check if given Triplet exists in the list of triplets in this set.
		/// </summary>
		/// <param name="triplet"> triplet to compare others with. </param>
		/// <returns> true if exists, otherwise false. </returns>
		public virtual bool Exists(Triplet triplet)
		{
			bool found = false;
			int cursor = this.Triplets.Count - 1;
			for (int j = cursor; j >= 0; j--)
			{
				Triplet currItem = this.Triplets[j];
				if (currItem.Equals(triplet))
				{
					found = true;
					break;
				}
				if (currItem.Weight < triplet.Weight)
				{
					break;
				}
			}
			return found;
		}

		public override string ToString()
		{
			return "CumulativeSet{" + "maximumCapacity=" + maximumCapacity + ", triplets=" + triplets + '}';
		}
	}

}