﻿using System.Collections.Generic;

namespace com.code.challenge.model
{

	/// <summary>
	/// Container to hold data parsed form input file.
	/// </summary>
	public class Problem
	{
		private IList<Triplet> triplets;
		private int maxCapacity;

        public Problem() { }
		public Problem(int maxCapacity)
		{
			this.maxCapacity = maxCapacity;
			triplets = new List<Triplet>();
		}

		public Problem(int maxCapacity, IList<Triplet> triplets)
		{
			this.maxCapacity = maxCapacity;
			this.triplets = triplets;
		}


		public virtual IList<Triplet> Triplets
		{
			get
			{
				return triplets;
			}
		}

		public virtual int MaxCapacity
		{
			get
			{
				return maxCapacity;
			}
		}

		public override string ToString()
		{
			return "Problem{" + "maxCapacity=" + maxCapacity + ", triplets=" + triplets + '}';
		}
	}


}