﻿using System;

namespace com.code.challenge.model
{

	/// <summary>
	/// A Triplet represents an item in a package.
	/// </summary>
	public class Triplet
	{
		private readonly int id;
		private readonly float weight;
		private readonly int cost;

		public Triplet(float weight, int cost) : this(0, weight, cost)
		{
		}

		public Triplet(int id, float weight, int cost)
		{
			this.id = id;
			this.weight = weight;
			this.cost = cost;
		}

		public virtual int Id
		{
			get
			{
				return id;
			}
		}

		public virtual float Weight
		{
			get
			{
				return weight;
			}
		}

		public virtual int Cost
		{
			get
			{
				return cost;
			}
		}

		public virtual float Ratio
		{
			get
			{
				return this.cost / this.weight;
			}
		}

		public override bool Equals(object o)
		{
			if (this == o)
			{
				return true;
			}
			if (o == null || this.GetType() != o.GetType())
			{
				return false;
			}
			Triplet triplet = (Triplet) o;
			return triplet.weight.CompareTo(weight) == 0 && cost == triplet.cost;
		}

		public override int GetHashCode()
		{
			return HashCode.Combine(id, weight, cost);


		}

        public override string ToString()
		{
			return "Triplet[" + "id=" + id + ", weight=" + weight + ", cost=" + cost + ']';
		}
	}

}