﻿using com.code.challenge.exception;
using System.Collections.Generic;
using System.Linq;

namespace com.code.challenge.packer
{
	using com.code.challenge.service;
	using APIException = APIException;
	using Problem = model.Problem;
	



	public class Packer
	{
		public static string Pack(string filePath)
		{
			Packing service = new CumulativePacking();
			IListFormatter formatter = new NewLineFormatter();

			IList<Problem> problems = Parser.Instance.Parse(filePath);

			IList<string> solutions = problems.Select(service.GetOptimalItemIdsInString).ToList();

            return formatter.Format(solutions);
		}

	}

}