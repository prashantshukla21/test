﻿
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;

namespace com.code.challenge.service
{
    using Util = utility.Util;
    using APIException = exception.APIException;
    using CumulativeSet = model.CumulativeSet;
    using Problem = model.Problem;
    using Triplet = model.Triplet;


    /// <summary>
    /// Concrete class to solve packing problem with Cumulative Approach.
    /// </summary>
    public class CumulativePacking : Packing
    {

        internal Merger merger;

        public const int MAX_TRIPLET_WEIGHT = 100;
        public const int MAX_TRIPLET_COST = 100;
        public const int MAX_TRIPLETS_SIZE_IN_PROBLEM = 15;

        public CumulativePacking()
        {
            this.merger = new Merger(this);
        }

        /// <summary>
        /// Solve Given problem and produce optimal item sequence as list of Triplets.
        /// </summary>
        /// <param name="problem"> </param>
        /// <returns> optimal triplets list </returns>
        public virtual IList<Triplet> GetOptimalTriplets(Problem problem)
        {

            ValidateProblem(problem);
            IList<CumulativeSet> sets = BuildCumulativeSets(problem);
            IList<Triplet> optimalTriplets = FindOptimalTripletsInCumulativeSets(problem, sets);

            return optimalTriplets;
        }

        /// <summary>
        /// Solve Given problem and produce optimal item sequence in a String.
        /// </summary>
        /// <param name="problem"> Includes package capacity and list of items with their costs and weight. </param>
        /// <returns> Selected triplet item ids in a comma delimited string and - for empty strings. </returns>
        public virtual string GetOptimalItemIdsInString(Problem problem)
        {
            IList<Triplet> optimalTriplets = GetOptimalTriplets(problem);

            string output = String.Join(",",optimalTriplets.Select(x => x.Id.ToString()));

            return Util.DefaultIfEmpty(output, "-");
        }

        /// <summary>
        /// Check a problem to have valid cost, weight and right number of items defined. </summary>
        /// <param name="problem"> Includes package capacity and list of items with their costs and weight. </param>
        private void ValidateProblem(Problem problem)
        {
            ValidateTripletCosts(problem);
            ValidateTripletWeights(problem);
            ValidateTripletMaxSize(problem);
        }

        /// <summary>
        /// validate right number of items be available in a problem. </summary>
        /// <param name="problem"> Includes package capacity and list of items with their costs and weight. </param>
        private void ValidateTripletMaxSize(Problem problem)
        {
            if (problem.Triplets.Count > MAX_TRIPLETS_SIZE_IN_PROBLEM)
            {
                throw new APIException(string.Format("Invalid problem : Max items possible is {0:D}", MAX_TRIPLETS_SIZE_IN_PROBLEM));
            }

        }

        /// <summary>
        /// Validate all items weight values to be in valid range. </summary>
        /// <param name="problem"> Includes package capacity and list of items with their costs and weight. </param>
        private void ValidateTripletWeights(Problem problem)
        {

            bool anyInvalidWeight = problem.Triplets.Select(x => x.Weight).Any(weight => weight > MAX_TRIPLET_WEIGHT || weight <= 0.0f);

            if (anyInvalidWeight)
            {
                throw new APIException(string.Format("Invalid problem : Max item weight possible is {0:D}", MAX_TRIPLET_WEIGHT));
            }

        }

        /// <summary>
        /// Validate all items cost values to be in valid range. </summary>
        /// <param name="problem"> Includes package capacity and list of items with their costs and weight. </param>
        private void ValidateTripletCosts(Problem problem)
        {

            bool anyInvalidCost = problem.Triplets.Select(x => x.Cost).Any(cost => cost > MAX_TRIPLET_COST || cost <= 0);

            if (anyInvalidCost)
            {
                throw new APIException(string.Format("Invalid problem : Max item cost possible is {0:D}", MAX_TRIPLET_COST));
            }
        }

        /// <summary>
        /// Create Cumulative Sets from triplet Items in a Problem.
        /// This Approach consists of two major operations: extend and merge
        /// <para>
        /// extend operation includes a Triplet Item from given problem and
        /// adds it's cost and value to the triplets chosen in the previous
        /// round (previous cumulativeSet).
        /// </para>
        /// <para>
        /// merge operation merges the result of extended set with the cumulative set
        /// in the last round and create a new cumulative set which includes
        /// a Cumulative Set including selected items in previous rounds and
        /// the new one in extend operation.
        /// 
        /// </para>
        /// </summary>
        /// <param name="problem"> Includes package capacity and list of items with their costs and weight.
        /// <Return></Return>
        private IList<CumulativeSet> BuildCumulativeSets(Problem problem)
        {

            SortProblemTripletsWithRatio(problem);
            
            IList<CumulativeSet> sets = GetInitializedCumulativeSets(problem);
            RemoveOverCapacityTriplets(problem);


            for (int i = 1; i < problem.Triplets.Count; i++)
            {
                CumulativeSet currentSet = sets[i - 1];
                IList<Triplet> extendedSet = this.Extend(currentSet, problem.Triplets[i]);
                IList<Triplet> mergedTriplets = merger.Merge(currentSet.Triplets.ToList(), extendedSet.ToList());
                if(mergedTriplets.Count > 0)
                    sets.Add(new CumulativeSet(mergedTriplets, currentSet.MaximumCapacity));
            }

            return sets;
        }

        /// <summary>
        /// finds optimal triplet items which results in a maximized packages gain cost.
        /// </summary>
        /// <param name="problem"> includes package capacity and list of items with their costs and weight. </param>
        /// <param name="sets">    list of cumulative sets resulted from  buildCumulativeSets method. </param>
        /// <returns> Selected optimal triplet items can be chosen to maximise profit. </returns>
        private IList<Triplet> FindOptimalTripletsInCumulativeSets(Problem problem, IList<CumulativeSet> sets)
        {
            //Triplet lastItem;
            int lastSetIndex = sets.Count - 1; // Start at last set
            int lastSetItem = sets[lastSetIndex].Triplets.Count - 1; // Get last item
            
            Triplet lastItem = sets[lastSetIndex].Triplets[lastSetItem];

            IList<Triplet> solution = new List<Triplet>();

            int cumulativeCost = lastItem.Cost;
            float cumulativeWeight = lastItem.Weight;
            Triplet prevTriplet = lastItem;

            for (int i = lastSetIndex - 1; i >= 0; i--)
            {
                int prevSetIndex = i+1;
                CumulativeSet currSet = sets[i];
                bool found = currSet.Exists(prevTriplet);
                // Pair (cum wgt, cum profit) not found in preceding set; item is in solution
                if (!found)
                {
                    solution.Add(problem.Triplets[prevSetIndex]);
                    cumulativeCost -= problem.Triplets[prevSetIndex].Cost;
                    cumulativeWeight = Util.Round(cumulativeWeight - problem.Triplets[prevSetIndex].Weight);
                    prevTriplet = new Triplet(cumulativeWeight, cumulativeCost);
                } // else keep searching for prev item in the next set
            }
            return solution;
        }

        /// <summary>
        /// Sort Triplet items in a problem based on ratio  cost/weight and the reverse the list.
        /// this way most valuable package with less weight would be in the head of the list.
        /// </summary>
        /// <param name="problem"> includes package capacity and list of items with their costs and weight. </param>
        private void SortProblemTripletsWithRatio(Problem problem)
        {
            List<Triplet> trip = problem.Triplets.OrderBy(x => x.Ratio).Reverse().ToList();
            //Problem prob;
            //problem.Triplets.OrderBy(x => x.Ratio).Reverse().ToList();

            foreach(Triplet triplet in problem.Triplets.ToList())
            {
                problem.Triplets.Remove(triplet);
            }

            foreach(Triplet trip1 in trip)
            {
                problem.Triplets.Add(trip1);
            }
        }

        /// <summary>
        /// Initialize Cumulative set with sentinel triplet item (0,0,0).
        /// </summary>
        /// <param name="problem"> includes package capacity and list of items with their costs and weight. </param>
        /// <returns> Initialized Cumulative sets with sentinel triplet. </returns>
        private IList<CumulativeSet> GetInitializedCumulativeSets(Problem problem)
        {
            IList<CumulativeSet> sets = new List<CumulativeSet>();

            CumulativeSet cumulativeSet = new CumulativeSet(problem.MaxCapacity);
            if (problem.Triplets.Count > 0)
            {
                cumulativeSet.Triplets.Add(problem.Triplets[0]);
                sets.Add(cumulativeSet);
            }
            return sets;
        }

        /// <summary>
        /// Prune Triplet items with weight exceeding the capacity defined in problem.
        /// </summary>
        /// <param name="problem"> includes package capacity and list of items with their costs and weight. </param>
        private void RemoveOverCapacityTriplets(Problem problem)
        {
            //problem.Triplets.Where(t => t.Weight > problem.MaxCapacity);
            foreach(Triplet removetriplet in problem.Triplets.Where(t => t.Weight > problem.MaxCapacity).ToList())
            {
                problem.Triplets.Remove(removetriplet);
            }
        }

        /// <summary>
        /// add Given A triplet, which represents an item in the package, to a cumulative set
        /// to include the impact of deciding to choose an item.
        /// The result sequence would be used to build new Cumulative Set which includes
        /// the decision of including given triplet item.
        /// </summary>
        /// <param name="set">     a set generated including all items before this one. </param>
        /// <param name="triplet"> represents an item in a package. </param>
        /// <returns> extended list including given item. </returns>
        private IList<Triplet> Extend(CumulativeSet set, Triplet triplet)
        {
            IList<Triplet> extendedTriplets = set.Triplets.Select(t => add(t, triplet)).Where(t => ValidCapacity(t, set.MaximumCapacity)).ToArray();
            return extendedTriplets;
        }

        /// <summary>
        /// Validate items wights to be under maximum capacity defined in a problem
        /// </summary>
        /// <param name="triplet">         represents an item in a package. </param>
        /// <param name="maximumCapacity"> maximum capacity a package can take,defined in a problem. </param>
        /// <returns> true if item weight is less than or equal maximum capacty,otherwise false. </returns>
        private bool ValidCapacity(Triplet triplet, int maximumCapacity)
        {
            if (triplet.Weight <= maximumCapacity)
            {
                return true;
            }

            return false;
        }

        /// <summary>
        /// add two triplets costs and weights and return new triplet item.
        /// </summary>
        /// <param name="triplet1"> represents an item in a package. </param>
        /// <param name="triplet2"> represents an item in a package. </param>
        /// <returns> new triplet result from adding given two triplets. </returns>
        public Triplet add(Triplet triplet1, Triplet triplet2)
        {
            int cumulativeCost = triplet1.Cost + triplet2.Cost;
            float cumulativeWeight = triplet1.Weight + triplet2.Weight;

            return new Triplet(triplet2.Id, cumulativeWeight, cumulativeCost);
        }

        /// <summary>
        /// Merge a List of Triplets from a Cumulative set with a List extended by
        /// choosing a triplet item using dominance pruning mechanism.
        /// </summary>
        internal class Merger
        {
            private readonly CumulativePacking outerInstance;

            private int firstPointer;
            private int firstMaxIndex;
            private int firstLastItemCost;

            private int secondPointer;
            private int secondMaxIndex;
            private int secondLastItemCost;
            List<Triplet> firstTriplets;
            List<Triplet> secondTriplets;
            public Merger(CumulativePacking outerInstance)
            {
                this.outerInstance = outerInstance;
            }

            /// <summary>
            /// Initializes pointers, max index and last item cost for first and second triplet items.
            /// </summary>
            /// <param name="firstTriplets"></param>
            /// <param name="secondTriplets"></param>
            public void Initialize(List<Triplet> firstTriplets, List<Triplet> secondTriplets)
            {

                firstPointer = 0;
                firstMaxIndex = firstTriplets.Count - 1;
                if(firstMaxIndex > -1)
                    firstLastItemCost = firstTriplets[firstMaxIndex].Cost;

                secondPointer = 0;
                secondMaxIndex = secondTriplets.Count - 1;
                if (secondMaxIndex > -1)
                    secondLastItemCost = secondTriplets[secondMaxIndex].Cost;

                this.firstTriplets = firstTriplets;
                this.secondTriplets = secondTriplets;
            }

            /**
         * In merge operation Items would be merged in a ascending order of weights with domination:
         * <p>
         * Domination is when one item has less weight and higher cost comparing to the other.
         * <p>
         * cases:
         * if item1 weight < other: write item1 to result and move second pointer until can not be dominated.
         * else if weights are equal move pointer for item dominated.
         * else if item1 weight > other: same logic holds for item2 in the first case.
         *
         * <param name="firstTriplets"/> firstTriplets  calculated cumulative triplet to include all items in the previous rounds.
         * <paramref name="secondTriplets"/> secondTriplets an extended triplets in which one specific item added contributing to total weights/cost.
         * <return>new merged list of triplet.</return> 
         */
            public List<Triplet> Merge(List<Triplet> firstTriplets, List<Triplet> secondTriplets)
            {

                this.Initialize(firstTriplets, secondTriplets);
                List<Triplet> result = new List<Triplet>();

                while (ArePointersNotTraversedCompletely())
                {
                    if (AreBothPointersInRange())
                    {
                        Triplet firstTriplet = firstTriplets[firstPointer];
                        Triplet secondTriplet = secondTriplets[secondPointer];

                        if (firstTriplet.Weight < secondTriplet.Weight)
                        {
                            result.Add(firstTriplet);    // Add item; can't be dominated by other item
                            firstPointer++;
                            MoveSecondPointerUntilNotDominated(firstTriplet, secondTriplet);

                        }
                        else if (firstTriplet.Weight == secondTriplet.Weight)
                        {
                            MoveDominatedPointerInCaseEqualWeights(firstTriplet, secondTriplet);

                        }
                        else
                        {
                            result.Add(secondTriplet);    //  Add other item, can't be dominated by item
                            secondPointer++;
                            MoveFirstPointerInCaseEqualWeights(firstTriplet, secondTriplet);
                        }
                    }
                    else if (firstPointer > firstMaxIndex)
                    {    // Only other items left to consider
                        AddSecondTripletToResultIfNotDominated(result);
                    }
                    else
                    {    // indexOther > maxIndexOther. Only items left to consider
                        AddFirstTripletToResultIfNotDominated(result);
                    }

                }
                return result;
            }

            /// <summary>
            /// Logic holds for the first case in merge operation:
            /// </summary>
            /// <param name="result"></param>
            private void AddFirstTripletToResultIfNotDominated(List<Triplet> result)
            {
                while (firstPointer <= firstMaxIndex)
                {
                    Triplet firstTriplet = firstTriplets[firstPointer];
                    if (firstTriplet.Cost > secondLastItemCost)
                        result.Add(firstTriplet);
                    firstPointer++;
                }
            }

            private void AddSecondTripletToResultIfNotDominated(List<Triplet> result)
            {
                while (secondPointer <= secondMaxIndex)
                {
                    Triplet secondTriplet = secondTriplets[secondPointer];
                    if (secondTriplet.Cost > firstLastItemCost)
                        result.Add(secondTriplet);
                    secondPointer++;
                }
            }

            private void MoveFirstPointerInCaseEqualWeights(Triplet firstTriplet, Triplet secondTriplet)
            {
                while (firstTriplet.Cost < secondTriplet.Cost && firstPointer <= firstMaxIndex)
                {    // item dominated; skip it
                    if (firstPointer == firstMaxIndex)
                    {
                        ++firstPointer;
                        break;
                    }
                    firstTriplet = firstTriplets[++firstPointer];
                }
            }

            /**
             * Logic holds for the second case in merge operation:
             * if weights are equal move pointer for item dominated. no item would add to result as
             * any of them could be dominated in the next round.
             */
            private void MoveDominatedPointerInCaseEqualWeights(Triplet thisTriplet, Triplet secondTriplet)
            {
                if (thisTriplet.Cost >= secondTriplet.Cost)    // Other item dominated
                    secondPointer++;
                else
                    firstPointer++;                            // Item dominated
            }

            
            /// <summary>
            /// Move Second Pointer until not dominated by second triplet.
            /// </summary>
            /// <param name="firstTriplet">firstTriplet represents a cumulative triplet</param>
            /// <param name="secondTriplet">secondTriplet represents a cumulative triplet.</param>
            private void MoveSecondPointerUntilNotDominated(Triplet firstTriplet, Triplet secondTriplet)
            {
                while (secondTriplet.Cost < firstTriplet.Cost && secondPointer <= secondMaxIndex)
                {    // Other item dominated; skip it
                    if (secondPointer == secondMaxIndex)
                    {
                        ++secondPointer;
                        break;
                    }
                    secondTriplet = secondTriplets[++secondPointer];
                }
            }

            
            /// <summary>
            /// Check if all items in both triplet lists are traversed.
            /// </summary>
            /// <returns>true if all items traversed, otherwise false.</returns>
            private Boolean ArePointersNotTraversedCompletely()
            {
                return firstPointer <= firstMaxIndex || secondPointer <= secondMaxIndex;
            }

            /// <summary>
            /// Check if both lists not traversed completely.
            /// </summary>
            /// <returns>false if any of the lists traversed, otherwise true.</returns>            
            private Boolean AreBothPointersInRange()
            {
                return firstPointer <= firstMaxIndex && secondPointer <= secondMaxIndex;
            }
        }
    }
}

