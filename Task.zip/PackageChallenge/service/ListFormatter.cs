﻿using System.Collections.Generic;

namespace com.code.challenge.service
{

	/// <summary>
	/// Define Formatter Protocol to be implemented by Concrete classes.
	/// </summary>
	public interface IListFormatter
	{
		string Format(IList<string> list);
	}

}