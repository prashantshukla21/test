﻿using System;
using System.Collections.Generic;
using System.Linq;

namespace com.code.challenge.service
{

	/// <summary>
	/// Concrete class to format a list of string by joining them with a line separator.
	/// </summary>
	public class NewLineFormatter : IListFormatter
	{
		public virtual string Format(IList<string> list)
		{
            return String.Join(Environment.NewLine, list);
			
            
        }
	}

}