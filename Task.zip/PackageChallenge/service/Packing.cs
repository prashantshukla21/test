﻿using System.Collections.Generic;

namespace com.code.challenge.service
{
	using Problem = com.code.challenge.model.Problem;
	using Triplet = com.code.challenge.model.Triplet;

	/// <summary>
	/// Define Packing Strategy Protocol to be implemeneted by Concrete classes
	/// </summary>
	public interface Packing
	{
		IList<Triplet> GetOptimalTriplets(Problem problem);

		string GetOptimalItemIdsInString(Problem problem);
	}

}