﻿using Microsoft.CodeAnalysis;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace com.code.challenge.service
{
	using APIException = exception.APIException;
	using Problem = model.Problem;
	using Triplet = model.Triplet;


	/// <summary>
	/// Parse packing input file.
	/// </summary>
	public class Parser
	{
		private bool InstanceFieldsInitialized = false;
        private readonly string tripletRegex = "(?<id>\\d+),(?<weight>\\d+\\.\\d+),\u20AC(?<cost>\\d+)";
        private string lineRegex;
        private Regex linePattern;
        private Regex tripletPattern;

        private static Parser parser;
        private void InitializeInstanceFields()
		{
			lineRegex = string.Format("(\\d+) : ((\\({0})\\s*\\)+)", tripletRegex);
            linePattern = new Regex(lineRegex, RegexOptions.Compiled);
            tripletPattern = new Regex(tripletRegex, RegexOptions.Compiled);
        }

		private Parser()
		{
			if (!InstanceFieldsInitialized)
			{
				InitializeInstanceFields();
				InstanceFieldsInitialized = true;
			}
		}

		/// <summary>
		/// Get single parser instance each time requested. </summary>
		/// <returns> Parser instance </returns>
		public static Parser Instance
		{
			get
			{
				if (parser == null)
				{
					lock (typeof(Parser))
					{
						if (parser == null)
						{
							parser = new Parser();
						}
					}
				}
				return parser;
			}
		}

		/// <summary>
		/// Parse given input file with problem definition to A list of Problems
		/// Problem instances correspond to each line defined in the file.
		/// </summary>
		/// <param name="filePath"> path to input problem file. </param>
		/// <returns> List of problem corresponding to what defined in input file. </returns>
		/// <exception cref="APIException"> when file content can not be parsed. </exception>

		public virtual IList<Problem> Parse(string filePath)
		{
			this.ValidateFilePath(filePath);

            IList<Problem> problems = new List<Problem>();
			try
			{
                // Open the file to read from.
                string[] readText = File.ReadAllLines(filePath, Encoding.UTF8);
                foreach (string s in readText)
                {
                    problems.Add(LineToProblem(s));
                }
			}
			catch (IOException e)
			{
				throw new APIException(e);
			}

			return problems;
		}

		/// <summary>
		/// Validate if given file exists. </summary>
		/// <param name="filePath"> Path to input file. </param>
		/// <exception cref="APIException"> when filePath is null or not exists. </exception>

		private void ValidateFilePath(string filePath)
		{
            //var path = new Uri(filePath).LocalPath;

            if (!File.Exists(filePath))
			{
				throw new APIException("Invalid parameter: file not exists");
			}
		}

		/// <summary>
		/// Convert a string line from file to Problem object </summary>
		/// <param name="line"> a line read from input file. </param>
		/// <returns> Problem object corresponding to given line. </returns>
		private Problem LineToProblem(string line)
		{

			if (!this.ValidateProblemInString(line))
			{
				throw new APIException(string.Format("Can not parse line: {0} ", line));
			}

			int capacity = GetCapacityFromStringProblem(line);
			IList<Triplet> triplets = GetTuplesFromStringProblem(line);

			return new Problem(capacity, triplets);
		}

		/// <summary>
		/// Validate a line read from input file with pattern expected. </summary>
		/// <param name="line"> a line read from input file. </param>
		/// <returns> true if line matches with expected pattern, otherwise false. </returns>
		private bool ValidateProblemInString(string line)
		{
            MatchCollection linetMatcher = linePattern.Matches(line);

            if (linetMatcher.Count == 0)
			{
				return false;
			}
			return true;
		}

		/// <summary>
		/// Parse Capacity value in a line read from a file. </summary>
		/// <param name="line"> a line read from input file. </param>
		/// <returns> integer value parsed as capacity. </returns>
		private int GetCapacityFromStringProblem(string line)
		{
			string[] splittedCapacityFromItems = line.Split(':');
			return int.Parse(splittedCapacityFromItems[0]);
		}

		/// <summary>
		/// Parse Triplets in a line read from a file. </summary>
		/// <param name="line"> a line read from input file. </param>
		/// <returns> list of triplets corresponding to the line read from a file. </returns>
		private IList<Triplet> GetTuplesFromStringProblem(string line)
		{
			string stringTriplets = line.Split(':')[1];
            MatchCollection tripletMatcher = tripletPattern.Matches(stringTriplets);
            IList<Triplet> triplets = new List<Triplet>();
			foreach (Match m in tripletMatcher)
			{
				Triplet triplet = new Triplet(int.Parse(m.Groups["id"].Value), float.Parse(m.Groups["weight"].Value), int.Parse(m.Groups["cost"].Value));
				triplets.Add(triplet);
			}
			return triplets;
		}
	}

}