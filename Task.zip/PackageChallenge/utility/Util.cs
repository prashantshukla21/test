﻿using System;

namespace com.code.challenge.utility
{

	/// <summary>
	/// General purpose functions.
	/// </summary>
	public class Util
	{
		/// <summary>
		/// Return String value or if it's empty return a default value. </summary>
		/// <param name="string"> string value to return value. </param>
		/// <param name="defaultValue"> default value to return in case string is empty. </param>
		/// <returns> string value or default if empty. </returns>
		public static string DefaultIfEmpty(string @string, string defaultValue)
		{
			return @string.Length == 0 ? defaultValue : @string;
		}

		/// <summary>
		/// round float value with two decimal points precision. </summary>
		/// <param name="value"> float value to round. </param>
		/// <returns> rounded float value. </returns>
		public static float Round(float value)
		{
			decimal bd = new decimal(value);
			    
            bd = Math.Round((decimal)bd, 2);

            return (float)bd;
		}
	}

}