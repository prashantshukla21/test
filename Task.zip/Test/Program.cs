﻿using com.code.challenge.packer;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Test
{
    public class Program
    {
        static void Main(string[] args)
        {
            string path = @"D:\DemoC#\PracticeTask\PackageChallenge\TextFile\multiline_problem.txt";

            Packer.Pack(path);

            Console.ReadLine();
        }
    }
}
